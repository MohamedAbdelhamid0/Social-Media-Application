
package com.mycompany.advancedproject;

public class AdvancedProject {

    public static void main(String[] args) {
    }
}
